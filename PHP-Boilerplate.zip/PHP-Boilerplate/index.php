<?php
//Designed By Daniyal Khan
header("location:Views/")

?>